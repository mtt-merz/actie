from lib.actor import Actor, Address
from lib.wsk import OpenWhisk, init_openwhisk

__app_name__ = "actie"
__version__ = "0.0.0"
