def main(args) -> dict:
    topic = args['topic']
    user = args['user']

    # get policy from subscriptions table
    # get last topic contents from contents table, depending on policy

    return args