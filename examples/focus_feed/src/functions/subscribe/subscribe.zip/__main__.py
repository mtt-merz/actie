def main(args) -> dict:
    topic = args['topic']
    user = args['user']
    policy = args['policy']

    # add to subscriptions table
    # get topic contents from contents table
    # call aggregate function

    return args