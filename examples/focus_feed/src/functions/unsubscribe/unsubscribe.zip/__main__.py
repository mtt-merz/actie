def main(args) -> dict:
    topic = args['topic']
    user = args['user']

    # remove from subscriptions table

    return args